# resource.images.busyspinners.basic
