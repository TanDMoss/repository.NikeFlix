from collections import namedtuple

SponsorSegment = namedtuple("SponsorSegment", ("uuid", "category", "start", "end"))
