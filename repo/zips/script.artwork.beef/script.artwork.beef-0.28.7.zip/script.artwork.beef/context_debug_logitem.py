from context import main

if __name__ == '__main__':
    main('debug')
