# -*- coding: utf-8 -*-
from xbmc import executebuiltin

executebuiltin('UpdateLibrary(video,special://skin/foo)')
